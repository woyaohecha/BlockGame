package com.union_test.toutiao.mediation.java.utils;

public class Const {
    public static final String TAG = "TMe_Demo";
}
