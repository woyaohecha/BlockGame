package com.union_test.toutiao.onepointfive;

/**
 * Created by linqiming on 6/27/22
 * Usage:
 * Doc:
 */
public interface TTOnPreloadListener {
    void onPreload();
}
