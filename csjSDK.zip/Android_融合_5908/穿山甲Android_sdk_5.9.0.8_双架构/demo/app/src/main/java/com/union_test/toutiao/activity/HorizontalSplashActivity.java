package com.union_test.toutiao.activity;

public class HorizontalSplashActivity extends CSJSplashActivity{
}
