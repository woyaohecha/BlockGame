package com.union_test.toutiao.view;

/**
 * Create by hanweiwei on 11/07/2018
 */
@SuppressWarnings("SpellCheckingInspection")
public interface ILoadMoreListener {

    /**
     * 加载更多回调
     */
    void onLoadMore();

}
